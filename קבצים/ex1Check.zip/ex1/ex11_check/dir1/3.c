When are you coming
whenever you wants
Tell me when
homework